# app.py
import os
import numpy as np
import pandas as pd
import streamlit as st
import pickle
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------- Paths / Constants ----------
MODEL_PATH = "student_advisor_gru.keras"
TOKENIZER_PATH = "tokenizer.pkl"
LABEL_ENCODER_PATH = "label_encoder.pkl"
FAQ_PATH = "faqs.csv"

# IMPORTANT: use the same maxlen as in training (train.py used maxlen=20)
MAXLEN = 20

# Confidence threshold for GRU before falling back to retrieval
GRU_CONF_THRESHOLD = 1.0

# ---------- Load GRU model & preprocessing assets ----------
@st.cache_resource(show_spinner=False)
def load_gru_assets():
    model = load_model(MODEL_PATH)
    with open(TOKENIZER_PATH, "rb") as f:
        tokenizer = pickle.load(f)
    with open(LABEL_ENCODER_PATH, "rb") as f:
        label_encoder = pickle.load(f)
    return model, tokenizer, label_encoder

# ---------- Load / init FAQs ----------
@st.cache_data(show_spinner=False)
def load_faqs():
    if os.path.exists(FAQ_PATH):
        df = pd.read_csv(FAQ_PATH)
    else:
        df = pd.DataFrame({"question": [], "answer": []})
        df.to_csv(FAQ_PATH, index=False)
    # Ensure columns exist
    for col in ["question", "answer"]:
        if col not in df.columns:
            df[col] = ""
    df["question"] = df["question"].fillna("").astype(str)
    df["answer"]  = df["answer"].fillna("").astype(str)
    return df.reset_index(drop=True)

# ---------- TF-IDF retriever ----------
@st.cache_resource(show_spinner=False)
def build_tfidf(faq_df):
    if len(faq_df) == 0:
        return None, None
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(faq_df["question"].tolist())
    return vectorizer, tfidf_matrix

# ---------- Core inference helpers ----------
def gru_predict_answer(gru_model, tokenizer, label_encoder, text):
    seq = tokenizer.texts_to_sequences([text])
    pad = pad_sequences(seq, maxlen=MAXLEN, padding="post", truncating="post")
    probs = gru_model.predict(pad, verbose=0)
    pred_idx = int(np.argmax(probs, axis=1)[0])
    confidence = float(np.max(probs))
    predicted_answer = label_encoder.inverse_transform([pred_idx])[0]
    return predicted_answer, confidence, pred_idx

def tfidf_faq_retrieve(vectorizer, tfidf_matrix, faq_df, text):
    if vectorizer is None or tfidf_matrix is None or len(faq_df) == 0:
        return "I don't have any FAQs yet. Please contact the department office.", 0.0, None
    query_vec = vectorizer.transform([text])
    sims = cosine_similarity(query_vec, tfidf_matrix).flatten()
    best_idx = int(np.argmax(sims))
    return faq_df.iloc[best_idx]["answer"], float(sims[best_idx]), best_idx

# ---------- UI setup ----------
st.set_page_config(page_title="FPTB CS — Student Advisor Chatbot", page_icon="🎓", layout="wide")
st.title("🎓 Student Advisor Chatbot")
st.caption("Department of Computer Science, Federal Polytechnic Bauchi")

# Load models & data
gru_model, tokenizer, label_encoder = load_gru_assets()

# Keep FAQs + TF-IDF in session so Admin updates can refresh instantly
if "faq_df" not in st.session_state:
    st.session_state.faq_df = load_faqs()
if "tfidf" not in st.session_state:
    st.session_state.vectorizer, st.session_state.tfidf_matrix = build_tfidf(st.session_state.faq_df)

# Sidebar nav
page = st.sidebar.radio("Navigation", ["💬 Chatbot", "🛠️ Admin Panel"])

# ---------- Chatbot Page ----------
if page == "💬 Chatbot":
    if "chat" not in st.session_state:
        st.session_state.chat = []  # list of dicts: {"role": "user"/"bot", "text": str}

    with st.form("chat_form", clear_on_submit=True):
        user_text = st.text_input("Ask a question (e.g., 'How do I register my courses?')", "")
        submitted = st.form_submit_button("Send")

    if submitted and user_text.strip():
        # 1) Try GRU
        answer, conf, pred_idx = gru_predict_answer(gru_model, tokenizer, label_encoder, user_text)

        if conf >= GRU_CONF_THRESHOLD:
            bot_text = answer
        else:
            # 2) Fallback: TF-IDF FAQ retrieval
            ans_faq, sim, best_idx = tfidf_faq_retrieve(
                st.session_state.vectorizer,
                st.session_state.tfidf_matrix,
                st.session_state.faq_df,
                user_text
            )
            bot_text = ans_faq

        st.session_state.chat.append({"role": "user", "text": user_text})
        st.session_state.chat.append({"role": "bot", "text": bot_text})

    # Render chat
    for msg in st.session_state.chat:
        if msg["role"] == "user":
            st.markdown(f"**👤 You:** {msg['text']}")
        else:
            st.markdown(f"**🤖 Bot:** {msg['text']}")

    c1, c2 = st.columns([1,1])
    if c1.button("Clear chat"):
        st.session_state.chat = []
    with st.expander("ℹ️ How responses are chosen"):
        #st.write(f"- GRU model is used first with a confidence threshold of {GRU_CONF_THRESHOLD:.2f}.")
        st.write("- If confidence is below threshold, the chatbot retrieves the closest FAQ using TF-IDF + cosine similarity.")

# ---------- Admin Panel ----------
else:
    st.subheader("Manage FAQs")
    st.write("Add / edit / delete FAQs. TF-IDF retriever refreshes automatically.")

    # Display & inline edit
    st.dataframe(st.session_state.faq_df, use_container_width=True)

    st.markdown("### ➕ Add new FAQ")
    new_q = st.text_input("Question", key="new_q")
    new_a = st.text_area("Answer", key="new_a")
    if st.button("Add FAQ"):
        if new_q.strip() and new_a.strip():
            st.session_state.faq_df.loc[len(st.session_state.faq_df)] = {
                "question": new_q.strip(),
                "answer": new_a.strip()
            }
            st.session_state.faq_df.to_csv(FAQ_PATH, index=False)
            st.session_state.vectorizer, st.session_state.tfidf_matrix = build_tfidf(st.session_state.faq_df)
            st.success("FAQ added and TF-IDF retriever refreshed.")
        else:
            st.warning("Please provide both question and answer.")

    st.markdown("### 🗑️ Delete FAQ")
    if len(st.session_state.faq_df) > 0:
        del_idx = st.number_input("Row index to delete", min_value=0, max_value=len(st.session_state.faq_df)-1, step=1)
        if st.button("Delete"):
            st.session_state.faq_df = st.session_state.faq_df.drop(del_idx).reset_index(drop=True)
            st.session_state.faq_df.to_csv(FAQ_PATH, index=False)
            st.session_state.vectorizer, st.session_state.tfidf_matrix = build_tfidf(st.session_state.faq_df)
            st.success("FAQ deleted and TF-IDF retriever refreshed.")
    else:
        st.info("No FAQs to delete yet.")

    st.markdown("### 💾 Save / Reload")
    c1, c2 = st.columns(2)
    if c1.button("Save FAQs to CSV"):
        st.session_state.faq_df.to_csv(FAQ_PATH, index=False)
        st.success("Saved to faqs.csv")
    if c2.button("Reload from CSV"):
        st.session_state.faq_df = load_faqs()
        st.session_state.vectorizer, st.session_state.tfidf_matrix = build_tfidf(st.session_state.faq_df)
        st.success("Reloaded FAQs and refreshed TF-IDF retriever.")
