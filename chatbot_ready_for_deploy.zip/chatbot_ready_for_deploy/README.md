# AI-Powered Chatbot for Student Advisor (Ready for Deployment)

This repository was prepared from the zip you uploaded. It uses **Streamlit** (app.py) and machine learning model files.

## Files added/changed for deployment
- `requirements.txt` — dependencies (renamed from `requirement.txt`)
- `Procfile` — start command for some hosts (Render). Streamlit Cloud ignores Procfile.

## How to deploy on Streamlit Community Cloud (free)
1. Create a GitHub repository and push all files from this repo to it.
2. Go to https://share.streamlit.io and sign in with your GitHub account.
3. Click **New app** → select your repository and the main file (`app.py`) and branch (usually `main`).
4. Click **Deploy**. Streamlit will install dependencies from `requirements.txt` and start the app.
5. After deploy, you'll get a URL like `https://share.streamlit.io/<your-username>/<repo>/<branch>/`.

## If you prefer Render.com
1. Create a GitHub repo and push files.
2. On Render, create a new Web Service, connect the repo, and set the start command to:
```
streamlit run app.py --server.port $PORT
```
3. Choose the free tier and deploy.

## Notes & troubleshooting
- Large model files (keras `.keras`, `.pkl`) may cause deploy to fail if >100MB. If you encounter size limits, consider:
  - Hosting model files on external storage (Google Drive, AWS S3) and download at app start.
  - Using Git LFS for large files.
- If deployment fails, open the logs on Streamlit/Render and paste them for help.